#!/bin/bash

# Set GitHub user
GITHUB_USER="CodeHex16"

# Fetch repositories using GitHub API and store in a temporary file
curl -s "https://api.github.com/orgs/$GITHUB_USER/repos?per_page=100" > repos.json

# Check if the API request was successful
if [ ! -f repos.json ]; then
    echo "Failed to fetch repositories list."
    exit 1
fi

# Loop through each line of the file containing the clone URLs
cat repos.json | grep -oP '"clone_url": "\K([^"]+)' | while read repo_url; do
    # Clone each repository using the clean URL
    echo "Cloning $repo_url"
    git clone "$repo_url"
done

# Clean up the temporary file
rm repos.json

echo "All repositories cloned!"
code SWE.code-workspace