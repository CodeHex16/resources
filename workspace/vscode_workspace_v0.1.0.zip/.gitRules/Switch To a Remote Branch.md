# Git Instructions: Switch to a Remote Branch

## Step 1: List All Remote Branches
Before switching to a remote branch, fetch the latest remote updates and list all available remote branches.

```bash
git fetch --all       # Fetch all remote updates
git branch -r         # List remote branches
```

## Step 2: Checkout a Remote Branch
To switch to a remote branch and create a local tracking branch, use the following command:

```bash
git checkout -b <branch-name> origin/<branch-name>
```
- Replace `<branch-name>` with target branch name.

### Example:

To switch to a remote branch called `diari-di-bordo` from the `origin` remote:

```bash
git checkout -b diari-di-bordo origin/diari-di-bordo
```

This will create a new local branch called `diari-di-bordo` and track the remote branch `origin/diari-di-bordo`.

## Step 3: Switch to an Already Tracked Remote Branch
If you've already checked out the branch before and it is being tracked locally, simply switch to it using:

```bash
git checkout <remote-branch-name>
```
## Step 4: Verify the Current Branch
After switching branches, you can verify that you've successfully switched by listing the branches:

```bash
git branch
```

This will display the current local branch, with an asterisk `*` next to it, indicating the active branch.

---

### Notes:
- The `git fetch --all` command ensures you have the latest remote branches before switching.
- The `git branch -r` command helps you confirm that the branch you're trying to switch to exists remotely.