# How to Create a Pull Request on GitHub

## Step 1: Create a New Branch
Before making changes, it's important to create a new branch. This keeps your changes isolated from the main branch `main`.

```bash
git checkout main     # Switch to the main branch
git pull origin main  # Get the latest changes

git checkout -b <[branch-name]-[autor]-[spint]> # Create a new branch and switch to it
```

## Step 2: Make Changes
Make the necessary changes to the code or documentation in your local repository.

## Step 3: Commit Your Changes
After making changes, commit them to your new branch.

```bash
git add .                      # Add all changes
git commit -m "A brief description of the changes"
```

## Step 4: Push Your Changes
Push your changes to the remote repository.

```bash
git push origin <[branch-name]-[autor]-[spint]>
```

## Step 5: Create a Pull Request (or with VsCode Plugin GitHub Pull Requests)
1. Go to the repository page on GitHub.
2. You should see a prompt to create a pull request for the branch you just pushed. Click on the **Compare & Pull Request** button.
3. Write a description of the changes you've made in the pull request.
4. Select the base branch `main` and the compare branch (the branch you just pushed).
5. Assign current sprint reviewer.
6. Click **Create Pull Request**.