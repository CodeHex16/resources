# How to Review a Pull Request on GitHub

## Step 1: Navigate to the Pull Request
1. Go to the GitHub repository.
2. Click on the **Pull Requests** tab to view all open PRs.
3. Select the PR you want to review.

## Step 2: Copy the PR Branch
1. Copy the branch name of the PR.
2. Create a new branch in your local repository with the same name.
3. Pull the changes from the PR branch.

```bash
git checkout -b <pr-branch-name> origin/<pr-branch-name>

# git checkout -b pr-typst-compile-check  origin/pr-typst-compile-check
```

## Step 3: Review the Changes
1. Inspect the changes made in the PR.
2. Run the code locally to test the changes.
3. ADD YOUR NAME TO TABELLA DEI VERSIONI.
4. EDIT IF NECESSARY.

## Step 4: Commit Your updates (if necessary)
After reviewing the changes, commit your updates to the PR branch.

```bash
git add .
git commit -m "Reviewed and updated PR"
git push origin <pr-branch-name>
```

## Step 5: Comment on the PR (if necessary)
1. Go back to the PR on GitHub.
2. Add comments to the PR with your feedback.

## Step 6: Approve or Request Changes
1. If the PR meets the requirements, approve it.
2. If changes are needed, request them from the author.
3. Approve the PR by VERIFICATORE